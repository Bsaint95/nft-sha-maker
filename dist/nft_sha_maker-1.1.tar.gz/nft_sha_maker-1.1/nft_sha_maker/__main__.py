from .nft_sha_maker import main

if __name__ == '__main__':
    main()
